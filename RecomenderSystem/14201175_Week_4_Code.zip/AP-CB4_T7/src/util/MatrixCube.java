/**
 * A class to represent a sparse matrix
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package util;

import java.util.HashMap;
import java.util.Map;

public class MatrixCube 
{
	private Map<Integer, Map<Integer,Map<Integer,Double>>> cube; //the data out
	
	/**
	 * constructor - creates a new Matrix object
	 */
	public MatrixCube()
	{
		cube=new HashMap<Integer, Map<Integer,Map<Integer,Double>>>();
	}
	
	
	/**
	 * adds an element  to the matrix
	 * @param userId - the user id
	 * @param rowId - the row id
	 * @param colId - the column id
	 */
	public void addElement(final Integer userId, final Integer rowId, final Integer colId, final Double entry)
	{
		Map<Integer,Map<Integer,Double>> movies= (cube.containsKey(userId))? cube.get(userId) : new HashMap<Integer, Map<Integer,Double>>();
		Map<Integer,Double> row = (movies.containsKey(rowId)) ? movies.get(rowId) : new HashMap<Integer,Double>();
		
		row.put(colId, entry);
		movies.put(rowId, row);
		cube.put(userId, movies);
		
	}
	
	/**
	 * @param rowId - the row id
	 * @param colId - the column id
	 * @return the (Double) element corresponding to (userId,rowId, colId) or null if the element is not present in the matrix
	 */
	public Double getElement(final Integer userId, final Integer rowId, final Integer colId)
	{
		Double elem=0.d;
		if(cube.containsKey(userId)){
			if(cube.get(userId).containsKey(rowId)){
				elem=cube.get(userId).get(rowId).get(colId);
			}else {
				return null;
			}
		}else{
			return null;
		}
		return elem;
	}
	
	/**
	 * @return a string representation of the object
	 */
	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		for(Integer userId:cube.keySet()){
			for(Integer rowId: cube.get(userId).keySet())
				buf.append(userId+" "+rowId + " " + cube.get(userId).get(rowId) + "\n");
		}
		return buf.toString();
	}
}
