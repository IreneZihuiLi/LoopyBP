package alg.weight;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import util.reader.DatasetReaderNew;

public class WeightFeature {

	public double weight = 0;
	public Map<Integer, ArrayList<String>> featureMap;
	public ArrayList<Integer> movieList;
	public Map<Integer, Double> userProfile;
	public Map<Integer, ArrayList<String>> movieGenres;

	/**
	 * constructor
	 */
	public WeightFeature() {

	}

	/**
	 * Used to get a person's genre weight given a userID
	 * @param distinct: number of distinct feature values
	 * @param total:number of total feature values
	 * @return person's genre weight
	 */
	public double getWeightGenre(DatasetReaderNew reader, Integer userId) {

		featureMap = new HashMap<Integer, ArrayList<String>>();
		movieList = new ArrayList<Integer>();
		movieGenres = new HashMap<Integer, ArrayList<String>>();
		userProfile = new HashMap<Integer, Double>();


		movieGenres = reader.getMovieGenres();
		userProfile = reader.getUserProfile(userId);

		Map<String, Integer> occurrence = new HashMap<String, Integer>();
		ArrayList<String> list = new ArrayList<String>();

		// get a list of movie Ids
		for (Integer movieId : userProfile.keySet()) {
			movieList.add(movieId);
		}

		for (int i = 0; i < movieList.size(); i++) {
			for (Integer movieId : movieGenres.keySet()) {
				if (movieList.get(i).equals(movieId)) {
					featureMap.put(movieId, movieGenres.get(movieId));
				}
			}
		}

		for (Integer movieId : featureMap.keySet()) {
			list = featureMap.get(movieId);
			for (int i = 0; i < list.size(); i++) {
				if (occurrence.containsKey(list.get(i))) {
					int times = occurrence.get(list.get(i));
					occurrence.put(list.get(i), 1 + times);
				} else {
					occurrence.put(list.get(i), 1);
				}
			}
		}

		// calculate times
		int distinct = occurrence.size();

		int total = 0;
		for (String str : occurrence.keySet()) {
			total += occurrence.get(str);

		}

		weight = 1 - ((double) (distinct - 1) / (double) total);

		return weight;
	}

	/**
	 * Used to get a person's director weight given a userID
	 * @param distinct: number of distinct feature values
	 * @param total:number of total feature values
	 * @return person's director weight
	 */
	public double getWeightDirector(DatasetReaderNew reader, Integer userId) {

		featureMap = new HashMap<Integer, ArrayList<String>>();
		movieList = new ArrayList<Integer>();
		movieGenres = new HashMap<Integer, ArrayList<String>>();
		userProfile = new HashMap<Integer, Double>();

		movieGenres = reader.getMovieDirectors();
		userProfile = reader.getUserProfile(userId);

		Map<String, Integer> occurrence = new HashMap<String, Integer>();
		ArrayList<String> list = new ArrayList<String>();

		// get a list of movie Ids
		for (Integer movieId : userProfile.keySet()) {
			movieList.add(movieId);
		}

		// match each movie, get a movie genre list of each movie
		for (int i = 0; i < movieList.size(); i++) {
			for (Integer movieId : movieGenres.keySet()) {
				if (movieList.get(i).equals(movieId)) {
					featureMap.put(movieId, movieGenres.get(movieId));
				}
			}
		}

		for (Integer movieId : featureMap.keySet()) {
			list = featureMap.get(movieId);
			for (int i = 0; i < list.size(); i++) {
				if (occurrence.containsKey(list.get(i))) {
					int times = occurrence.get(list.get(i));
					occurrence.put(list.get(i), 1 + times);
				} else {
					occurrence.put(list.get(i), 1);
				}
			}
		}

		// calculate times
		int distinct = occurrence.size();

		int total = 0;
		for (String str : occurrence.keySet()) {
			total += occurrence.get(str);

		}

		weight = 1 - ((double) (distinct - 1) / (double) total);

		return weight;
	}

}
