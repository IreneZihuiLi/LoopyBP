/**
 * An abstract class to define a case-based recommender
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.recommender;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import util.Matrix;
import util.MatrixCube;
import util.reader.DatasetReader;
import util.reader.DatasetReaderNew;
import alg.cases.similarity.CaseSimilarity;
import alg.cases.similarity.CaseSimilarityNew;

public abstract class RecommenderNew 
{
	private Matrix matrixActor; // a Matrix object to store unchanged values
	private Matrix matrixDirctor; // a Matrix to store Feature Genres matrix
	private Matrix matrixGenre; // a Matrix to store Feature Genres matrix
	private Map<Integer, Double> weights;
	private Map<Integer, Double> weightsD;

	/**
	 * constructor - creates a new Recommender object
	 * @param caseSimilarity - an object to compute case similarity
	 * @param reader - an object to store user profile data and movie metadata
	 */
	public RecommenderNew(final CaseSimilarityNew caseSimilarity, final DatasetReaderNew reader)
	{
		// compute all case similarities and store in a Matrix object
		this.matrixActor = new Matrix();
		this.matrixGenre=new Matrix();
		this.matrixDirctor=new Matrix();
		
		this.weights=new HashMap<Integer, Double>();
		this.weightsD=new HashMap<Integer, Double>();
		
		Set<Integer> ids = reader.getCasebase().getIds();
		
		//a userId list
		Set<Integer> userIds=reader.getUserIds();
		System.out.println("userIds: "+userIds);
		for(Integer rowId: ids)
			for(Integer colId: ids)
				if(rowId.intValue() != colId.intValue())
				{
					double above1 = caseSimilarity.getSimilarityBaseActor(reader.getCasebase().getCase(rowId), reader.getCasebase().getCase(colId));
					double above2 = caseSimilarity.getSimilarityChangeGenre(reader.getCasebase().getCase(rowId), reader.getCasebase().getCase(colId));
					double above3 = caseSimilarity.getSimilarityChangeDirector(reader.getCasebase().getCase(rowId), reader.getCasebase().getCase(colId));
					if(above1 > 0){
						matrixActor.addElement(rowId, colId, above1);
					}
					if(above3 > 0){
						matrixDirctor.addElement(rowId, colId, above2);
					
					}
					if(above2 > 0){
						//	System.out.println("add "+above2);
						matrixGenre.addElement(rowId, colId, above2);
						
					}
					
				}
		
		//get weights of all the users
		for(Integer userId:userIds){
			weights.put(userId,caseSimilarity.getWeightGenre(userId));

		}
		

		//get weights of all the users
		for(Integer userId:userIds){
			weightsD.put(userId,caseSimilarity.getWeightDirector(userId));

		}
	
	}
	
	/**
	 * returns the case similarity between two cases(only the genres)
	 * @param userId - the user Id
	 * @param rowId - the id of the first case
	 * @param colId - the id of the second case
	 * @return the case similarity or null if the Matrix object does not contain the case similarity
	 */
	public Double getCaseSimilarity(final Integer userId,final Integer rowId, final Integer colId)
	{
		double above1=0;
		double above2=0;
		double above3=0;
		if(matrixActor.getElement(rowId, colId)!=null){
			above1= matrixActor.getElement(rowId, colId);
		}
		if(matrixDirctor.getElement(rowId, colId)!=null){
			above2= matrixDirctor.getElement(rowId, colId);
		}
		if(matrixGenre.getElement(rowId, colId)!=null){
			above3= matrixGenre.getElement(rowId, colId);
		}
		
		double GENRE_WEIGHT=weights.get(userId);
		
		double DIRECTOR_WEIGHT=1;
		double ACTOR_WEIGHT=1;
		double above= above1*ACTOR_WEIGHT+above2*DIRECTOR_WEIGHT+above3*GENRE_WEIGHT;
		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT;

		return (below > 0) ? above / below : 0;
	}
	
	
	/**
	 * returns the case similarity between two cases(change director only)
	 * @param userId - the user Id
	 * @param rowId - the id of the first case
	 * @param colId - the id of the second case
	 * @return the case similarity or null if the Matrix object does not contain the case similarity
	 */
	public Double getCaseSimilarity1(final Integer userId,final Integer rowId, final Integer colId)
	{
		double above1=0;
		double above2=0;
		double above3=0;
		if(matrixActor.getElement(rowId, colId)!=null){
			above1= matrixActor.getElement(rowId, colId);
		}
		if(matrixDirctor.getElement(rowId, colId)!=null){
			above2= matrixDirctor.getElement(rowId, colId);
		}
		if(matrixGenre.getElement(rowId, colId)!=null){
			above3= matrixGenre.getElement(rowId, colId);
		}
		//get weights
		double GENRE_WEIGHT=1;
//		double DIRECTOR_WEIGHT=weightsD.get(userId);
		double DIRECTOR_WEIGHT=weights.get(userId);
		double ACTOR_WEIGHT=1;
		double above= above1*ACTOR_WEIGHT+above2*DIRECTOR_WEIGHT+above3*GENRE_WEIGHT;
		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT;

		return (below > 0) ? above / below : 0;
	}
	
	/**
	 * returns the case similarity between two cases(Change genre and director together)
	 * @param userId - the user Id
	 * @param rowId - the id of the first case
	 * @param colId - the id of the second case
	 * @return the case similarity or null if the Matrix object does not contain the case similarity
	 */
	public Double getCaseSimilarity2(final Integer userId,final Integer rowId, final Integer colId)
	{
		double above1=0;
		double above2=0;
		double above3=0;
		//get all the elements from matrixs
		if(matrixActor.getElement(rowId, colId)!=null){
			above1= matrixActor.getElement(rowId, colId);
		}
		if(matrixDirctor.getElement(rowId, colId)!=null){
			above2= matrixDirctor.getElement(rowId, colId);
		}
		if(matrixGenre.getElement(rowId, colId)!=null){
			above3= matrixGenre.getElement(rowId, colId);
		}
		
		double GENRE_WEIGHT=weights.get(userId);
		double DIRECTOR_WEIGHT=weightsD.get(userId);
		double ACTOR_WEIGHT=1;
		double above= above1*ACTOR_WEIGHT+above2*DIRECTOR_WEIGHT+above3*GENRE_WEIGHT;
		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT;

		return (below > 0) ? above / below : 0;
	}
	
	/**
	 * returns a ranked list of recommended case ids
	 * @param userId - the id of the target user
	 * @param reader - an object to store user profile data and movie metadata
	 * @return the ranked list of recommended case ids
	 */
	public abstract ArrayList<Integer> getRecommendations(final Integer userId, final DatasetReaderNew reader);
}
