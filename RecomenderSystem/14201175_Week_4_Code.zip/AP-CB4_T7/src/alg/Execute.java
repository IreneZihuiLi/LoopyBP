/**
 * Used to evaluate the case-based recommendation algorithm
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import alg.cases.similarity.CaseSimilarity;
import alg.cases.similarity.CaseSimilarityNew;
import alg.cases.similarity.JaccardCaseSimilarity;
import alg.cases.similarity.OverlapCaseSimilarity;
import alg.cases.similarity.OverlapCaseSimilarityNew;
import alg.recommender.MaxRecommender;
import alg.recommender.MaxRecommenderNew;
import alg.recommender.Recommender;
import alg.recommender.MeanRecommender;
import alg.recommender.RecommenderNew;
import util.evaluator.Evaluator;
import util.evaluator.EvaluatorNew;
import util.reader.DatasetReader;
import util.reader.DatasetReaderNew;

public class Execute {
	public static void main(String[] args) {
		// set the paths and filenames of the training, test and movie metadata
		// files and read in the data
		String trainFile = "dataset" + File.separator + "trainData.txt";
		String testFile = "dataset" + File.separator + "testData.txt";
		String movieFile = "dataset" + File.separator + "movies.txt";
		// set a file named result.csv, to store this way, makes it easier to generate charts in Excel
		String outputFile = "results" + File.separator + "Task7_dir.csv";

//		DatasetReader reader = new DatasetReader(trainFile, testFile, movieFile);
		DatasetReaderNew reader = new DatasetReaderNew(trainFile, testFile, movieFile);
		// configure the case-based recommendation algorithm - set the case
		// similarity and recommender, change the comments here for Jaccard and Overlap!!
		
		CaseSimilarityNew caseSimilarity = new OverlapCaseSimilarityNew(reader);
		//CaseSimilarity caseSimilarity = new OverlapCaseSimilarity();

		// Two recommenders are created for both Mean and Max ways at one time.

		//Recommender recommender = new MaxRecommender(caseSimilarity,reader);
		RecommenderNew recommender=new MaxRecommenderNew(caseSimilarity, reader);

		// evaluate the case-based recommender

//		Evaluator eval = new Evaluator(recommender, reader);
		EvaluatorNew eval = new EvaluatorNew(recommender, reader);
		
		// Write the results out nicely, each time the Mean and Max could be figured out given one run
		File file = new File(outputFile);
		try {
			BufferedWriter output = new BufferedWriter(new FileWriter(file));
			//Write out the header of the file.
			output.write("topN，Recall,Precision\n");
			//Print out on console
			System.out.println("topN,Recall,Precision");
			for (int topN = 5; topN <= 50; topN += 5){
				//Write out the values that we need.
				output.write(topN + "," 
						+ eval.getRecall(topN) + ","
						+ eval.getPrecision(topN) +"\n");
				//Print out on console
				System.out.println(topN + ","
						+ eval.getRecall(topN) + ","
						+ eval.getPrecision(topN));
			}

			
			output.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done!");

	}
}
