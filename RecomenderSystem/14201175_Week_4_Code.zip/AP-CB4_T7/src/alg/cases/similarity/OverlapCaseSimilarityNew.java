/**
 * A class to compute the case similarity between objects of type MovieCase
 * Uses the overlap feature similarity metric
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.cases.similarity;

import util.reader.DatasetReaderNew;
import alg.cases.Case;
import alg.cases.MovieCase;
import alg.feature.similarity.FeatureSimilarity;
import alg.weight.WeightFeature;

public class OverlapCaseSimilarityNew implements CaseSimilarityNew
{
	double GENRE_WEIGHT = 0; // the weight for feature genres
	final static double DIRECTOR_WEIGHT = 1; // the weight for feature directors
	final static double ACTOR_WEIGHT = 1; // the weight for feature actors
	
	WeightFeature wf=new WeightFeature();
	DatasetReaderNew reader;
	
	/**
	 * constructor - creates a new OverlapCaseSimilarity object
	 */
	public OverlapCaseSimilarityNew()
	{}
	
	/**
	 * new constructor - with the DatasetReaderNew object being a parameter.
	 * @param reader
	 */
	public OverlapCaseSimilarityNew(DatasetReaderNew reader)
	{
		this.reader=reader;
	}
	/**
	 * computes the similarity between two cases
	 * @param c1 - the first case
	 * @param c2 - the second case
	 * @return the similarity between case c1 and case c2
	 */
	public double getSimilarityBaseActor(final Case c1, final Case c2) 
	{
		MovieCase m1 = (MovieCase)c1;
		MovieCase m2 = (MovieCase)c2;
		
		double above = ACTOR_WEIGHT * FeatureSimilarity.overlap(m1.getActors(), m2.getActors())+GENRE_WEIGHT*FeatureSimilarity.overlap(m1.getGenres(), m2.getGenres());
//		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT;
		
		return above;
	}
	
	public double getSimilarityChangeDirector(final Case c1, final Case c2) 
	{
		MovieCase m1 = (MovieCase)c1;
		MovieCase m2 = (MovieCase)c2;
		
//		System.out.println("userid "+userId +" weight "+GENRE_WEIGHT);
		//OverLap 
		double above = FeatureSimilarity.overlap(m1.getDirectors(), m2.getDirectors());
		
		
		return above;
	}
	
	public double getSimilarityChangeGenre(final Case c1, final Case c2) 
	{
		MovieCase m1 = (MovieCase)c1;
		MovieCase m2 = (MovieCase)c2;
		
		
		double above = FeatureSimilarity.overlap(m1.getGenres(), m2.getGenres());
//		double above= FeatureSimilarity.overlap(m1.getDirectors(), m2.getDirectors());
		
		
		return above;
	}
	
	/**
	 * compute the weight
	 */
	public double getWeightGenre(Integer userId){
		double genreWeight=0;
//		System.out.println("***Reader"+reader.getMovieGenres());

		genreWeight=wf.getWeightGenre(reader, userId);
		return genreWeight;
	}
	
	public double getWeightDirector(Integer userId){
		double genreWeight=0;
//		System.out.println("***Reader"+reader.getMovieGenres());

		genreWeight=wf.getWeightDirector(reader, userId);
		return genreWeight;
	}
	
	/**
	 * compute the final case similarities
	 */
	public double getSimilarityFinal(double above1,double above2,Integer userId){
		GENRE_WEIGHT=getWeightGenre(userId);
		
		double above= above1+above2*GENRE_WEIGHT;
		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT;
		
		return (below > 0) ? above / below : 0;
		
	}
	
	
	
}
