/**
 * An interface to compute the similarity between cases
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.cases.similarity;

import alg.cases.Case;
import alg.cases.MovieCase;
import alg.feature.similarity.FeatureSimilarity;

public interface CaseSimilarityNew 
{
	/**
	 * computes the similarity between two cases
	 * @param c1 - the first case
	 * @param c2 - the second case
	 * @return the similarity between case c1 and case c2
	 */
//	public double getSimilarity(final Case c1, final Case c2,Integer userId);
	public double getSimilarityBaseActor(final Case c1, final Case c2);
	
	public double getSimilarityChangeGenre(final Case c1, final Case c2);
	public double getSimilarityChangeDirector(final Case c1, final Case c2);
	/**
	 * compute the weight
	 */
	public double getWeightGenre(Integer userId);
	public double getWeightDirector(Integer userId);
	
	/**
	 * compute the final case similarities
	 */
	public double getSimilarityFinal(double above1,double above2,Integer userId);
}
