/**
 * A class to compute the case similarity between objects of type MovieCase
 * Uses the overlap feature similarity metric
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.cases.similarity;

import java.util.Map;

import util.Matrix;
import util.reader.DatasetReaderNew;
import alg.cases.Case;
import alg.cases.MovieCase;
import alg.feature.similarity.FeatureSimilarity;
import alg.feature.similarity.FeatureSimilarityNew;

public class OverlapCaseSimilarityNew implements CaseSimilarity
{
	final static double GENRE_WEIGHT = 1; // the weight for feature genres
	final static double DIRECTOR_WEIGHT = 1; // the weight for feature directors
	final static double ACTOR_WEIGHT = 1; // the weight for feature actors
	final static double RATING_WEIGHT = 1;
	
	Matrix movieRating=null;
	/**
	 * constructor - creates a new OverlapCaseSimilarity object
	 */
	public OverlapCaseSimilarityNew()
	{}
	
	public OverlapCaseSimilarityNew(DatasetReaderNew reader){
		this.movieRating=reader.getMovieRating();
	}
	/**
	 * computes the similarity between two cases
	 * @param c1 - the first case
	 * @param c2 - the second case
	 * @return the similarity between case c1 and case c2
	 */
	public double getSimilarity(final Case c1, final Case c2) 
	{
		MovieCase m1 = (MovieCase)c1;
		MovieCase m2 = (MovieCase)c2;
		Integer movieId1=m1.getId();
		Integer movieId2=m2.getId();
		
		//Get the rating HashMaps of the given cases.
		Map<Integer, Double> movieRating1=this.movieRating.getRow(movieId1);
		Map<Integer, Double> movieRating2=this.movieRating.getRow(movieId2);

		//OverLap 
		double above = GENRE_WEIGHT * FeatureSimilarityNew.overlap(m1.getGenres(), m2.getGenres()) + 
				DIRECTOR_WEIGHT * FeatureSimilarityNew.overlap(m1.getDirectors(), m2.getDirectors()) + 
				ACTOR_WEIGHT * FeatureSimilarityNew.overlap(m1.getActors(), m2.getActors())+
				// add Pearson Similarity Rating
				RATING_WEIGHT * FeatureSimilarityNew.PearsonRating(movieRating1, movieRating2);
		
		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT + RATING_WEIGHT;
		
	
		return (below > 0) ? above / below : 0;
	}
}
