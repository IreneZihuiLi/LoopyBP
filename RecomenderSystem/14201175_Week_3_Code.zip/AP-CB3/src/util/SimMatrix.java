/**
 * A class to represent a sparse matrix
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package util;

import java.util.HashMap;
import java.util.Map;

public class SimMatrix 
{
	private Map<Integer,Map<Integer,Integer>> matrix; 
	// the data structure used to store case similarities
	private Integer numMovies=0;
	// numMovies is used to calculate the number of records
	/**
	 * constructor - creates a new Matrix object
	 */
	public SimMatrix()
	{
		matrix = new HashMap<Integer,Map<Integer,Integer>>();
	}
	
	/**
	 * adds an element  to the matrix
	 * @param rowId - the row id
	 * @param colId - the column id
	 */
	public void addElement(final Integer rowId, final Integer colId, final Integer entry)
	{
		numMovies++;
		Map<Integer,Integer> row = (matrix.containsKey(rowId)) ? matrix.get(rowId) : new HashMap<Integer,Integer>();
		row.put(colId, entry);
		matrix.put(rowId, row);
	}
	
	/**
	 * @param rowId - the row id
	 * @param colId - the column id
	 * @return the (Integer) element corresponding to (rowId, colId) or null if the element is not present in the matrix
	 */
	public Integer getElement(final Integer rowId, final Integer colId)
	{
		return (matrix.containsKey(rowId)) ? matrix.get(rowId).get(colId) : null;
	}
	
	/**
	 * 
	 * @return the number of the records
	 */
	public Integer getSize()
	{
		return numMovies;
	}
	
	/**
	 * @return a string representation of the object
	 */
	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		for(Integer rowId: matrix.keySet())
			buf.append(rowId + " " + matrix.get(rowId) + "\n");
		return buf.toString();
	}
}
