package alg.recommender;

import java.util.ArrayList;

import util.reader.DatasetReader;
import alg.cases.Case;
import alg.cases.similarity.CaseSimilarity;
import alg.cases.similarity.CaseSimilarityNew;
import alg.cases.similarity.OverlapCaseSimilarity;
import alg.cases.similarity.OverlapCaseSimilarityNew2;

public class BoundedGreedySelection {
	
	CaseSimilarity caseSimilarity=new OverlapCaseSimilarityNew2();
//	DatasetReader reader=new DatasetReader(trainFile, testFile, movieFile);

//	Recommender recommender= new MaxRecommenderNew2(caseSimilarity, reader);
	ArrayList<Integer> recommendationIds = new ArrayList<Integer>();
	ArrayList<Integer> rprimeIds = new ArrayList<Integer>();
	Integer targetId=0;
	Integer candidateId=0;
	
	
	public BoundedGreedySelection(DatasetReader reader){
		
	}
	
	/**
	 * get Quality of t,c and R
	 */
	public double getQuality(Case t, Case c, ArrayList<Case> R){
//		Recommender recommender=new MaxRecommenderNew2(caseSimilarity, reader);
		double quality=0;
		System.out.println("sim"+caseSimilarity.getSimilarity(t, c));
		quality=caseSimilarity.getSimilarity(t, c) * getRelDiv(c, R);
		return quality;
	}
	
	/**
	 * get get RelativeDiversity of c and R
	 */
	public double getRelDiv(Case c,ArrayList<Case> R){
//		Recommender recommender=new MaxRecommenderNew2(caseSimilarity, reader);
		double rel=0;
		double temp=0;
		if(R.size() == 0){
			rel=1;
		}else{
			for(int i=0;i<R.size();i++){
				temp+=(1-caseSimilarity.getSimilarity(c, R.get(i)));
			}
			rel=temp/R.size();
		}
		return rel;
	}
	
	

}
