/**
 * A class to define a case-based recommender.
 * The scoring function used to rank recommendation candidates is the mean similarity to the target user's profile cases.
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.recommender;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import util.ScoredThingDsc;
import util.reader.DatasetReader;
import util.reader.DatasetReaderNew;
import alg.cases.Case;
import alg.cases.similarity.CaseSimilarity;
import alg.cases.similarity.CaseSimilarityNew;

public class MaxRecommenderNew2 extends Recommender {
	/**
	 * constructor - creates a new MeanRecommender object
	 * 
	 * @param caseSimilarity
	 *            - an object to compute case similarity
	 * @param reader
	 *            - an object to store user profile data and movie metadata
	 */
	public MaxRecommenderNew2(final CaseSimilarity caseSimilarity,
			final DatasetReader reader) {
		super(caseSimilarity, reader);
	}

	/**
	 * returns a ranked list of recommended case ids
	 * 
	 * @param userId
	 *            - the id of the target user
	 * @param reader
	 *            - an object to store user profile data and movie metadata
	 * @return the ranked list of recommended case ids
	 */
	Integer userInteger = 0;

	public ArrayList<Integer> getRecommendations(final Integer userId,
			final DatasetReader reader) {

		// Bounded Greedy Selection
		// Give values to b and k
		Integer b = 2;
		Integer k = 20;
		SortedSet<ScoredThingDsc> ss = null;
		SortedSet<ScoredThingDsc> ssCandidate = new TreeSet<ScoredThingDsc>();
		SortedSet<ScoredThingDsc> ssMap = new TreeSet<ScoredThingDsc>();
		// HashMap for eliminating same film
		Map<Integer, Double> recomendationMap = new LinkedHashMap<Integer, Double>();

		double simtc = 0;
		// get the target user profile
		Map<Integer, Double> profile = reader.getUserProfile(userId);

		// get the ids of all recommendation candidate cases
		Set<Integer> candidateIds = reader.getCasebase().getIds();

		// Set an ArrayList to store all the scores get from the matrix
		ArrayList<Double> scores = null;

		// compute a score for all recommendation candidate cases
		for (Integer id : profile.keySet()) {

			// initialize the ArrayList each time
			scores = new ArrayList<Double>();
			double score = 0;
			ss = new TreeSet<ScoredThingDsc>();

			// iterate over all the target user profile cases---each movie and
			// compute a
			// score for the current recommendation candidate case
			for (Integer candidateId : candidateIds) {

				if (!profile.containsKey(candidateId)) {
					// put every value into a big set
					Double sim = super.getCaseSimilarity(candidateId, id);
					if ((sim != null) && (sim > 0)) {
						score = sim;
						simtc = sim;
						ss.add(new ScoredThingDsc(score, candidateId));
					}

				}

			}

			ArrayList<Integer> recommendationIds = new ArrayList<Integer>();

			LinkedHashMap<Integer, Double> Cprime = new LinkedHashMap<Integer, Double>();
			LinkedHashMap<Integer, Double> CprimeSorted = new LinkedHashMap<Integer, Double>();
			LinkedHashMap<Integer, Double> R = new LinkedHashMap<Integer, Double>();

			// Bounded Algorithm--Generate C' set
			Iterator<ScoredThingDsc> it = ss.iterator();
			while (it.hasNext() && Cprime.size() < b * k) {
				ScoredThingDsc st = it.next();
				recommendationIds.add((Integer) st.thing);

				Cprime.put((Integer) st.thing, st.score);

			}

			// add elements to set R
			for (int i = 0; i < k; i++) {
				
				//Sort C’ by Quality(t, c, R) for each c in C’
				CprimeSorted = SortCprime(id, Cprime, R);
				Cprime = CprimeSorted;

				// Find the first element of C',then add to R, then remove from C'
				if (Cprime.size() > 0) {
					Integer key = Cprime.keySet().iterator().next();
					if (Cprime.get(key) != null) {
						if (Cprime.get(key) == Double.NaN)
							System.out.println("Nan");
						R.put(key, Cprime.get(key));
						Cprime.remove(key);
					}

				}

			}

			// Combine all the Rs and sort
			for (Integer str : R.keySet()) {
				if (recomendationMap.containsKey(str)) {
					Double newScore = recomendationMap.get(str);
					if (newScore > R.get(str)) {
						recomendationMap.put(str, newScore);
					}
				} else {
					recomendationMap.put(str, R.get(str));
				}
			}

			for (Integer str : recomendationMap.keySet()) {

				if (str != id)
					ssCandidate.add(new ScoredThingDsc(recomendationMap
							.get(str), str));

			}

		}

		// Sort recomendationMap,combine Rs
		for (Integer str : recomendationMap.keySet()) {

			// recommendationIdsSelected.add(str);
			ssMap.add(new ScoredThingDsc(recomendationMap.get(str), str));

		}

		//Generate a list of recommend movies(according to the sorting)
		ArrayList<Integer> recommendationIdsSelected = new ArrayList<Integer>();

		for (Iterator<ScoredThingDsc> itMap = ssMap.iterator(); itMap.hasNext();) {
			ScoredThingDsc st = itMap.next();
			recommendationIdsSelected.add((Integer) st.thing);
		}

		userInteger++;
//		System.out.println("---" + userId + "<<<<"
//				+ recommendationIdsSelected.size() + "	users" + userInteger);
//		System.out.println(">>>>>>>>>"+userId+"<<<<"+recommendationIdsSelected.size());
		return recommendationIdsSelected;

	}

	/**
	 * get Quality of t,c and R
	 */
	public double getQuality(Integer t, Integer c,
			LinkedHashMap<Integer, Double> R) {
	
		Double quality = 0.d;

		if (super.getCaseSimilarity(t, c) != null) {
			
			quality = super.getCaseSimilarity(t, c) * getRelDiv(c, R);
			if (quality.equals(Double.NaN)) {
				System.out.println("Quality " + quality);
				
			}
		} else {
			quality = 0.d;

		}

		return quality;
	}

	/**
	 * get get RelativeDiversity of c and R
	 */
	public double getRelDiv(Integer c, LinkedHashMap<Integer, Double> R) {
		Double rel = 0.d;
		Double temp = 0.d;
		int sum = 0;
		if (R.size() != 0) {
			for (Integer mid : R.keySet()) {
				if (getCaseSimilarity(c, mid) != null) {

					temp += (1 - (double) super.getCaseSimilarity(c, mid));
					sum++;

				}

			}
			if (sum != 0) {
				rel = temp / (double) sum;

			} else {
				rel = 1.0;
			}
		} else {

			rel = 1.0;
		}
		return rel;
	}

	/**
	 * the sorting method of C' 
	 */
	public LinkedHashMap<Integer, Double> SortCprime(Integer t,
			LinkedHashMap<Integer, Double> Cprime,
			LinkedHashMap<Integer, Double> R) {
		LinkedHashMap<Integer, Double> CprimeChange = new LinkedHashMap<Integer, Double>();
		SortedSet<ScoredThingDsc> sts = new TreeSet<ScoredThingDsc>();

		for (Integer mid : Cprime.keySet()) {
			Double quality = 0.d;
			quality = getQuality(t, mid, R);

			sts.add(new ScoredThingDsc(quality, mid));
		}

		for (Iterator<ScoredThingDsc> it = sts.iterator(); it.hasNext();) {
			ScoredThingDsc st = it.next();

			CprimeChange.put((Integer) st.thing, st.score);

		}

		Cprime = CprimeChange;

		return Cprime;
	}

}
