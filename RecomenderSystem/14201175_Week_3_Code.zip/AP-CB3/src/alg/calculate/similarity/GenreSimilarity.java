package alg.calculate.similarity;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.math3.analysis.function.Min;

import util.SimMatrix;
import util.reader.DatasetReaderNew;

public class GenreSimilarity {

	SimMatrix genereSimMatrix = new SimMatrix();
	Map<Integer, ArrayList<String>> movieGenres;
	Map<String, Integer> genresMap; // a list of genres:23 records
	ArrayList<String> genres; // ??!!
	DatasetReaderNew reader;

	/**
	 * constructor - creates a new OverlapCaseSimilarity object
	 */
	public GenreSimilarity() {
	}

	public GenreSimilarity(DatasetReaderNew reader) {
		CalSimMatrix(reader);
	}

	
	public SimMatrix getSimMatrix() {
		return genereSimMatrix;
	}

	public ArrayList<String> getGenreList() {
		return genres;
	}

	/**
	 * use the reader to get the records, then add elements to the SimMatrix.
	 * @param datasetreader
	 * @return a matrix of genres(occur times)
	 */
	public SimMatrix CalSimMatrix(DatasetReaderNew reader) {
		// get the casebase
		movieGenres = reader.getMovieGenres();
		genres = new ArrayList<String>();

		genresMap = reader.getGenresMap();

		// get a list of genres.
		for (String genre : genresMap.keySet()) {
			genres.add(genre);
		}

		// initialize the matrix
		for (int i = 0; i < genres.size(); i++) {
			for (int j = 0; j < genres.size(); j++) {
				Integer times = 0;
				genereSimMatrix.addElement(i, j, times);
			}
		}

		// update the value, if a genre occurs then update by adding 1 to its element
		for (Integer movieId : movieGenres.keySet()) {
			for (int i = 0; i < genres.size(); i++) {
				for (int j = 0; j < genres.size(); j++) {
					Integer times = genereSimMatrix.getElement(i, j);
					if (movieGenres.get(movieId).contains(genres.get(i))
							&& movieGenres.get(movieId).contains(genres.get(j))) {
						genereSimMatrix.addElement(i, j, times + 1);
					}
				}
			}
		}
		
		return genereSimMatrix;
	}

	/**
	 * calculate the similarity of the genre pair
	 * @param s1 row number
	 * @param s2 col number
	 * @return the similarity of the given genre pair
	 */
	public double getPairSim(String s1, String s2) {
		ArrayList<String> genreList;
		genreList = getGenreList();
		Integer gsm=0;
		gsm = genereSimMatrix.getSize();
		Integer row = 0;
		Integer col = 0;
		double sim = 0;
		
		//Find out the right positions of the given genres 
		for (int i = 0; i < genreList.size(); i++) {
			if (genreList.get(i).equals(s1))
				row = i;
		}
		for (int j = 0; j < genreList.size(); j++) {
			if (genreList.get(j).equals(s2))
				col = j;
		}

//		sim = ((double) genereSimMatrix.getElement(row, col))
//				/ (Math.max((double) genereSimMatrix.getElement(row, row),
//						(double) genereSimMatrix.getElement(col, col)));
		sim=((double) genereSimMatrix.getElement(row, col))/(double)(gsm);

		return sim;
	}

}
