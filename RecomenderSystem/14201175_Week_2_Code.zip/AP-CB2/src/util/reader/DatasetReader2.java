/**
 * A class to read in and store user profile data and movie metadata. Also reads in test user profile data.
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package util.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import alg.casebase.Casebase;
import alg.cases.MovieCase2;

public class DatasetReader2 {
	private Casebase cb; // stores case objects
	private Map<Integer, Map<Integer, Double>> userProfiles; // stores training
																// user profiles
	private Map<Integer, Map<Integer, Double>> testProfiles; // stores test user
																// profiles

	private Map<Integer, ArrayList<Double>> movieRatings; // ???

	/**
	 * constructor - creates a new DatasetReader object
	 * 
	 * @param trainFile
	 *            - the path and filename of the file containing the training
	 *            user profile data
	 * @param testFile
	 *            - the path and filename of the file containing the test user
	 *            profile data
	 * @param itemFile
	 *            - the path and filename of the file containing case metadata
	 */
	public DatasetReader2(final String trainFile, final String testFile,
			final String movieFile) {

		// read in movie ratings, aiming at calculating the mean and popularity
		// of each movie
		movieRatings = getMovieRatings(trainFile);

		// read the movies as casebase, for the Task3 the Movie metadata.
		readCasebase(movieFile, movieRatings);

		userProfiles = readUserProfiles(trainFile);

		testProfiles = readUserProfiles(testFile);
		
		//choose one as the filter---For Task4
//		movieFiltGlobal(userProfiles, testProfiles);
//		movieFiltPerson(userProfiles, testProfiles);

	}

	/**
	 * @return the training user profile ids
	 */
	public Set<Integer> getUserIds() {
		return userProfiles.keySet();
	}

	/**
	 * @param id
	 *            - the id of the training user profile to return
	 * @return the training user profile
	 */
	public Map<Integer, Double> getUserProfile(final Integer id) {
		return userProfiles.get(id);
	}

	/**
	 * @return the test user profile ids
	 */
	public Set<Integer> getTestIds() {
		return testProfiles.keySet();
	}

	/**
	 * @param id
	 *            - the id of the test user profile to return
	 * @return the test user profile
	 */
	public Map<Integer, Double> getTestProfile(final Integer id) {
		return testProfiles.get(id);
	}

	/**
	 * @return the casebase
	 */
	public Casebase getCasebase() {
		return cb;
	}

	/**
	 * @param filename
	 *            - the path and filename of the file containing the user
	 *            profiles
	 * @return the user profiles
	 */
	private Map<Integer, Map<Integer, Double>> readUserProfiles(
			final String filename) {
		Map<Integer, Map<Integer, Double>> map = new HashMap<Integer, Map<Integer, Double>>();

		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(
					filename)));
			String line;
			br.readLine(); // read in header line

			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, "\t");
				if (st.countTokens() != 4) {
					System.out.println("Error reading from file \"" + filename
							+ "\"");
					System.exit(1);
				}

				Integer userId = new Integer(st.nextToken());
				Integer movieId = new Integer(st.nextToken());
				Double rating = new Double(st.nextToken());
				String review = st.nextToken();

				Map<Integer, Double> profile = (map.containsKey(userId) ? map
						.get(userId) : new HashMap<Integer, Double>());

				profile.put(movieId, rating);
				map.put(userId, profile);
			}

			br.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		return map;
	}

	/**
	 * creates the casebase
	 * 
	 * @param filename
	 *            - the path and filename of the file containing the movie
	 *            metadata
	 */
	private void readCasebase(final String filename,
			Map<Integer, ArrayList<Double>> movieRatings) {
		Map<Integer, ArrayList<Double>> movieRating = new HashMap<Integer, ArrayList<Double>>();
		ArrayList<Double> rating_list = new ArrayList<Double>();
		cb = new Casebase();
		movieRating = movieRatings;
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(
					filename)));
			String line;

			// Test codes
			//

			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, "\t");
				if (st.countTokens() != 5) {
					System.out.println("Error reading from file \"" + filename
							+ "\"");
					System.out.println(line);
					System.out.println(st.countTokens());
					System.exit(1);
				}

				Integer id = new Integer(st.nextToken());
				String title = st.nextToken();
				ArrayList<String> genres = tokenizeString(st.nextToken());
				ArrayList<String> directors = tokenizeString(st.nextToken());
				ArrayList<String> actors = tokenizeString(st.nextToken());
				Integer popularity = null;
				Double meanRating = null;

				rating_list = movieRating.get(id);
				popularity = rating_list.size();
				
				Double sum = 0.d;
				for (int j = 0; j < rating_list.size(); j++)
					sum += rating_list.get(j);
				// Get the mean rating of each movie
				meanRating = sum / popularity;
				// Create a new movieCase
				MovieCase2 movie = new MovieCase2(id, title, genres, directors,
						actors, popularity, meanRating);
				

				
				cb.addCase(id, movie);

			}
			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		// System.out.println("cb has "+ cb.size());

	}

	/**
	 * creates the movie rating hash which used to update the moviecase
	 * 
	 * @param filename
	 *            - the path and filename of the file containing the movie
	 *            metadata
	 */
	private Map<Integer, ArrayList<Double>> getMovieRatings(
			final String filename) {
		// to store the movie ratings as a HashMap
		Map<Integer, ArrayList<Double>> movieRatings = new HashMap<Integer, ArrayList<Double>>();
		// a temp list to store the ratings each time ???
		ArrayList<Double> rating_list = new ArrayList<Double>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(
					filename)));
			String line;
			br.readLine(); // read in header line

			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, "\t");
				if (st.countTokens() != 4) {
					System.out.println("Error reading from file \"" + filename
							+ "\"");
					System.exit(1);
				}

				Integer userId = new Integer(st.nextToken());
				Integer movieId = new Integer(st.nextToken());
				Double rating = new Double(st.nextToken());
				String review = st.nextToken();

				if (movieRatings.containsKey(movieId)) {

					rating_list = movieRatings.get(movieId);

					rating_list.add(rating);

				} else {

					rating_list.add(rating);

				}

				movieRatings.put(movieId, rating_list);
				rating_list = new ArrayList<Double>();
				// System.out.println(map_movie_rating);

			}

			br.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		// System.out.println(movieRatings);
		return movieRatings;
	}

	/**
	 * @param str
	 *            - the string to be tokenized; ',' is the delimiter character
	 * @return a list of string tokens
	 */
	private ArrayList<String> tokenizeString(final String str) {
		ArrayList<String> al = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(str, ",");
		while (st.hasMoreTokens())
			al.add(st.nextToken().trim());

		return al;
	}

	/**
	 * @param the two maps generated by the training set and testing set
	 * @return ignores the movies less than the Global thresholds
	 */
	public void movieFiltGlobal(Map<Integer, Map<Integer, Double>> mapTrain,
			Map<Integer, Map<Integer, Double>> mapTest) {

		// set the global threshold----can be changed to 3.5, 4.0,... 
		Double threshold = 3.0;
		Map<Integer, Double> ratings = new HashMap<Integer, Double>();

		// deal with the training file
		for (Integer key : mapTrain.keySet()) {
			
			// get the rating map of each user
			ratings = mapTrain.get(key);

			// for each movie, compare the rating to the threshold
			// if it is less than the threshold, we remove the rating from the hashmap

			Iterator<Map.Entry<Integer, Double>> iter1 = ratings.entrySet()
					.iterator();
			while (iter1.hasNext()) {
				Map.Entry<Integer, Double> entry = iter1.next();
				if (entry.getValue() < threshold) {
					iter1.remove();
				}
			}

		}

		// deal with the testing file
		for (Integer key : mapTest.keySet()) {
			// get the rating map of each user
			ratings = mapTest.get(key);

			// for each movie, compare the rating to the threshold
			// if it is less than the threshold, we remove the rating from the hashmap
			Iterator<Map.Entry<Integer, Double>> iter1 = ratings.entrySet()
					.iterator();
			while (iter1.hasNext()) {
				Map.Entry<Integer, Double> entry = iter1.next();
				if (entry.getValue() < threshold) {
					iter1.remove();
				}
			}

		}

		System.out.println("Filter done!");

	}

	/**
	 * @param the two maps generated by the training set and testing set
	 * @return ignores the movies less than the Personal threshold
	 */
	public void movieFiltPerson(Map<Integer, Map<Integer, Double>> mapTrain,
			Map<Integer, Map<Integer, Double>> mapTest) {

		Double rating = 0.d;
		//sumout is used to keep the users that has exceed our standard
		Integer sumout = 0;
		
		Map<Integer, Double> ratings = new HashMap<Integer, Double>();
		Map<Integer, Double> ratingsTest = new HashMap<Integer, Double>();

		for (Integer key : mapTrain.keySet()) {

			// get the rating map of each user
			ratings = mapTrain.get(key);
			
			// use this class to compute mean and standard deviate
			DescriptiveStatistics ds = new DescriptiveStatistics();
			for (Integer movieKey : ratings.keySet()) {
				rating = ratings.get(movieKey);
				// put all the ratings of a user gives into ds
				ds.addValue(rating);
			}
			
			// compute by using ds, and generate the threshold as μ+ωσ
			Double meanRating = ds.getMean();
			Double sdRating = ds.getStandardDeviation();
			// om is the ω in μ+ωσ, could be 0.1,0.3 or 0.5
			Double om=0.5;
			Double threshold = meanRating + om * sdRating;

			// keep count how much users that exceed the threshold
			// if threshold is larger than 4.5, set it to 4.5
			if (threshold > 4.5) {
				sumout += 1;
				threshold = 4.5;
			}
			
			
			// for each movie, compare the rating to the threshold
			// if it is less than the threshold, we remove the rating from the hashmap
			// ignore movies in training file
			Iterator<Map.Entry<Integer, Double>> movieIter = ratings.entrySet()
					.iterator();
			while (movieIter.hasNext()) {
				Map.Entry<Integer, Double> entry = movieIter.next();
				if (entry.getValue() < threshold) {
					movieIter.remove();
				}
			}

			// ignore the movies in testing files
			for (Integer key2 : mapTest.keySet()) {
				if (key2.equals(key)) {
					ratingsTest = mapTest.get(key2);
					Iterator<Map.Entry<Integer, Double>> movieIterTest = ratingsTest
							.entrySet().iterator();
					while (movieIterTest.hasNext()) {
						Map.Entry<Integer, Double> entryTest = movieIterTest
								.next();
						if (entryTest.getValue() < threshold) {
							movieIterTest.remove();
						}
					}
				}
			}

		}
		
		// give how many users are out range
		System.out.println("Exceed users numbers: " + sumout);

	}

}
