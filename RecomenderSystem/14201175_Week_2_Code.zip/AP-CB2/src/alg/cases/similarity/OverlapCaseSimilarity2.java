/**
 * A class to compute the case similarity between objects of type MovieCase
 * Uses the overlap feature similarity metric
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.cases.similarity;

import alg.cases.Case;
import alg.cases.MovieCase;
import alg.cases.MovieCase2;
import alg.feature.similarity.FeatureSimilarity;
import alg.feature.similarity.FeatureSimilarity2;

public class OverlapCaseSimilarity2 implements CaseSimilarity {
	final static double GENRE_WEIGHT = 1; // the weight for feature genres
	final static double DIRECTOR_WEIGHT = 1; // the weight for feature directors
	final static double ACTOR_WEIGHT = 1; // the weight for feature actors
	final static double POPULARITY_WEIGHT = 1; // the weight for feature popularity
	final static double MEAN_WEIGHT = 1; // the weight for feature mean

	/**
	 * constructor - creates a new OverlapCaseSimilarity object
	 */
	public OverlapCaseSimilarity2() {
	}

	/**
	 * computes the similarity between two cases
	 * 
	 * @param c1
	 *            - the first case
	 * @param c2
	 *            - the second case
	 * @return the similarity between case c1 and case c2
	 */
	public double getSimilarity(final Case c1, final Case c2) {
		
		// Change to the new moviecase class
		MovieCase2 m1 = (MovieCase2) c1;
		MovieCase2 m2 = (MovieCase2) c2;

		// Add the new two weight
		double above = GENRE_WEIGHT
				* FeatureSimilarity2.overlap(m1.getGenres(), m2.getGenres())
				+ DIRECTOR_WEIGHT
				* FeatureSimilarity2.overlap(m1.getDirectors(),
						m2.getDirectors())
				+ ACTOR_WEIGHT
				* FeatureSimilarity2.overlap(m1.getActors(), m2.getActors())
				+ POPULARITY_WEIGHT
				* FeatureSimilarity2.AsymmetricPorpularity1(m1.getPopularity(),
						m2.getPopularity())
				+ MEAN_WEIGHT
				* FeatureSimilarity2.SymmetricMean(m1.getMeanRating(),
						m2.getMeanRating());

		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT
				+ POPULARITY_WEIGHT + MEAN_WEIGHT;

		return (below > 0) ? above / below : 0;
	}
}
