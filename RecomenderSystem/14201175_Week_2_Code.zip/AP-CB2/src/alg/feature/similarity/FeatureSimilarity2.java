/**
 * A class containing various feature similarity metric implementations
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.feature.similarity;

import java.util.Set;

import org.apache.commons.math3.analysis.function.Abs;

public class FeatureSimilarity2 
{
	/**
	 * computes exact match similarity between string feature values
	 * @param s1 - the first feature value
	 * @param s2 - the second feature value
	 * @return the similarity between string feature values
	 */
	//Don't use it.
	public static double exact(final String s1, final String s2)
	{
		if(s1.trim().compareToIgnoreCase(s2.trim()) == 0) return 1.0;
		else return 0.0;
	}
	
	/**
	 * computes overlap similarity between set feature values
	 * @param s1 - the first feature value
	 * @param s2 - the second feature value
	 * @return the similarity between set feature values
	 */
	public static double overlap(final Set<String> s1, final Set<String> s2) 
	{
		int intersection = 0;
		
		for(String str: s1)
			if(s2.contains(str))
				intersection++;
		
		int min = (s1.size() < s2.size()) ? s1.size() : s2.size();		
		return (min > 0) ? intersection * 1.0 / min : 0;
	}
	
	/**
	 * computes Jaccard similarity between set feature values
	 * @param s1 - the first feature value
	 * @param s2 - the second feature value
	 * @return the similarity between set feature values
	 */	
	public static double Jaccard(final Set<String> s1, final Set<String> s2) 
	{
		int intersection = 0;
		
		for(String str: s1)
			if(s2.contains(str))
				intersection++;
		
		int union = s1.size() + s2.size() - intersection;		
		return (union > 0) ? intersection * 1.0 / union : 0;
	}
	
	/**
	 * computes Symmetric similarity between set feature values by using Mean
	 * @param meanT - the target feature value
	 * @param meanC - the candidate feature value
	 * @return the similarity between set feature values
	 */	
	public static double SymmetricMean(Double meanT, Double meanC) 
	{
		double sim=0.d;
		
		sim=1-(Math.abs(meanT-meanC)/meanT);
	
		return sim;
	}
	
	/**
	 * computes Symmetric similarity between set feature values by using Porpularity
	 * @param meanT - the target feature value
	 * @param meanC - the candidate feature value
	 * @return the similarity between set feature values
	 */	
	public static double SymmetricPorpularity(Integer popularT, Integer popularC) 
	{
		double sim=0.d;
		//sim=(1-(Math.abs(popularT-popularC)/popularT));
		
		sim=(1-(Math.abs((double)popularT-(double)popularC)/(double)popularT));
		
		return sim;
	}
	
	

	
	/**
	 * computes Asymmetric similarity between set feature values by using Porpularity, method1
	 * @param meanT - the target feature value
	 * @param meanC - the candidate feature value
	 * @return the similarity between set feature values
	 */	
	public static double AsymmetricPorpularity1(Integer popularC, Integer popularT) 
	{
		double sim=0.d;
		sim=(double) (1-(Math.abs((double)popularT-(double)popularC)/Math.max((double)popularT,(double)popularC)));
		return sim;
	}
	
	/**
	 * computes Asymmetric similarity between set feature values by using Popularity, method2
	 * @param meanT - the target feature value
	 * @param meanC - the candidate feature value
	 * @return the similarity between set feature values
	 */	
	public static double AsymmetricPorpularity2(Integer popularC, Integer popularT) 
	{
		Double sim=0.d;
		sim=1-(Math.abs(popularT-popularC)/(popularT+Math.max(0.d,popularT-popularC)));
		return sim;
	}
	

	/**
	 * computes Asymmetric similarity between set feature values by using Mean, method1
	 * @param meanT - the target feature value
	 * @param meanC - the candidate feature value
	 * @return the similarity between set feature values
	 */	
	public static double AsymmetricMean1(Double meanC, Double meanT) 
	{
		Double sim=0.d;
		sim=1-(Math.abs(meanT-meanC)/Math.max(meanT,meanC));
		return sim;
	}
	/**
	 * computes Asymmetric similarity between set feature values by using Mean, method2
	 * @param meanT - the target feature value
	 * @param meanC - the candidate feature value
	 * @return the similarity between set feature values
	 */	
	public static double AsymmetricMean2(Double meanC, Double meanT) 
	{
		Double sim=0.d;
		sim=1-(Math.abs(meanT-meanC)/(meanT+Math.max(0.d,meanT-meanC)));
		return sim;
	}
}
