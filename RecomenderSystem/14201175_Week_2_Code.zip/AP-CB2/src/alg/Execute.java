/**
 * Used to evaluate the case-based recommendation algorithm
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import alg.cases.similarity.CaseSimilarity;
import alg.cases.similarity.JaccardCaseSimilarity;
import alg.cases.similarity.OverlapCaseSimilarity;
import alg.cases.similarity.OverlapCaseSimilarity2;
import alg.recommender.MaxRecommender;
import alg.recommender.MaxRecommender2;
import alg.recommender.Recommender;
import alg.recommender.MeanRecommender;
import alg.recommender.Recommender2;
import util.evaluator.Evaluator;
import util.evaluator.Evaluator2;
import util.reader.DatasetReader;
import util.reader.DatasetReader2;

public class Execute 
{
	public static void main(String[] args)
	{	
		// set the paths and filenames of the training, test and movie metadata files and read in the data
		String trainFile = "dataset" + File.separator + "trainData.txt";
		String testFile = "dataset" + File.separator + "testData.txt";
		String movieFile = "dataset" + File.separator + "movies.txt";
		String outputFile = "results" + File.separator + "task4b_05.csv";
		
//		DatasetReader reader = new DatasetReader(trainFile, testFile, movieFile);

		
		DatasetReader2 reader = new DatasetReader2(trainFile, testFile, movieFile);
		// configure the case-based recommendation algorithm - set the case similarity and recommender
		
		
		//For Task3 use the OverlapCaseSimilarity2, for Task4 use the OverlapCaseSimilarity.
//		CaseSimilarity caseSimilarity = new OverlapCaseSimilarity();
		CaseSimilarity caseSimilarity = new OverlapCaseSimilarity2();


		//CaseSimilarity Interface
		Recommender2 recommender = new MaxRecommender2(caseSimilarity, reader);
//		Recommender recommender = new MaxRecommender(caseSimilarity, reader);

		
		// evaluate the case-based recommender
//		Evaluator eval=new Evaluator(recommender, reader);
		Evaluator2 eval = new Evaluator2(recommender, reader);
		
		File file = new File(outputFile);
		try {
			BufferedWriter output = new BufferedWriter(new FileWriter(file));
			
			//write out the recall and precision, to both csv file and the console
			output.write("topN,Recall,Precision"+"\n");
			System.out.println("topN,Recall,Precision");
			for(int topN = 5; topN <= 50; topN += 5){
				output.write(topN + "," +eval.getRecall(topN)+","+eval.getPrecision(topN)+"\n");
				System.out.println(topN + ","+eval.getRecall(topN)+","+eval.getPrecision(topN));

			}
	        output.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done!");
		
		
	}
}
