/**
 * A class to represent a sparse matrix
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package util;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MatrixTerm 
{
	private Map<Integer,Map<String,Integer>> matrixTerm; // the data structure used to store case similarities
	private Integer size=0;
	/**
	 * constructor - creates a new Matrix object
	 */
	public MatrixTerm()
	{
		matrixTerm = new HashMap<Integer,Map<String,Integer>>();
	}
	
	
	
	/**
	 * Get the matrix
	 * @return matrixTerm
	 */
	public Map<Integer,Map<String,Integer>> getMatrix(){
		return matrixTerm;
	}
	/**
	 * 
	 * @param the movieId 
	 * @return the vecter(hashmap structured) of term-times
	 */
	public Map<String,Integer> getRows(final Integer rowID){
		return matrixTerm.get(rowID);
	}
	/**
	 * adds an element  to the matrix
	 * @param rowId - the row id
	 * @param colId - the column id
	 */
	public void addElement(final Integer rowId, final String colId, final Integer entry)
	{
		Integer sum=0;
		
		Map<String,Integer> row =null;
		if(matrixTerm.containsKey(rowId)){
			row=matrixTerm.get(rowId);
			if(this.getElement(rowId, colId)!=null){
				sum=this.getElement(rowId, colId);
				sum=sum+entry;
			
				row.put(colId, sum);
			}else{
				
				
				row.put(colId, entry);
				
			}
		}else{

			
			row=new HashMap<String, Integer>();
			row.put(colId, entry);
		}
		
	
		matrixTerm.put(rowId, row);

	}
	
	/**
	 * @param rowId - the row id
	 * @param colId - the column id
	 * @return the (Double) element corresponding to (rowId, colId) or null if the element is not present in the matrix
	 */
	public Integer getElement(final Integer rowId, final String colId)
	{
		return (matrixTerm.containsKey(rowId)) ? matrixTerm.get(rowId).get(colId) : null;
	}
	
	/**
	 * get norm of the col with given rowId
	 * 
	 */
	public Integer getColNorm(final Integer movieId)
	{
		Integer norm=0;
		if(this.getMatrix().get(movieId)!=null){
			for(String term:this.getMatrix().get(movieId).keySet()){
				if((this.getMatrix().get(movieId).get(term)!=null)&&(this.getMatrix().get(movieId).get(term)>norm)){
					norm = this.getMatrix().get(movieId).get(term);
				}
			}
		}
		
		return norm;
	}
	
	/**
	 * @param the term
	 * @return the IDF of each row.
	 */
	public double calIDF( final String term)
	{
		double idf=0;
		Integer times=0;
		times=getRowNorm(term);
		size=matrixTerm.size();
		idf=Math.log10((double)size/(double)(1+times));
		return idf;
	}
	
	/**
	 * Calculate TF-IDF of an element with the given col and row ID
	 * @param term
	 * @param movieId
	 * @return TF-IDF value
	 */
	public double getTFIDF(final String term,final Integer movieId)
	{
		Integer elem=this.getElement(movieId,term);
		if(elem==null){
			System.out.println("elem null ");
			return 0.0;
		}else{
			return ((double)elem/(double)this.getColNorm(movieId))*calIDF(term);
		}
	}
	
	/**
	 * get binary number of a row( how many times that a term occurs among all the movies)
	 */
	public Integer getRowNorm(final String term)
	{
		Integer sum=0;
		for(Integer movieId:matrixTerm.keySet()){
			if(this.getElement(movieId, term)!=null){
				sum++;
			}
		}
		return sum;
		
	}
	
	
	
	/**
	 * @return a string representation of the object
	 */
	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		for(Integer rowId: matrixTerm.keySet()){
	//		if(matrixTerm.get(rowId).size()>1)
				System.out.print("****************************");
			buf.append(rowId + " " + matrixTerm.get(rowId) + "\n");
		}
		return buf.toString();
	}
}
