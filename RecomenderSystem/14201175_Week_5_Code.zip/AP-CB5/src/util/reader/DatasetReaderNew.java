/**
 * A class to read in and store user profile data and movie metadata. Also reads in test user profile data.
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package util.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import util.*;

import java.util.Arrays;
import java.util.Map;
import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;

import util.MatrixTerm;
import alg.casebase.Casebase;
import alg.cases.MovieCase;

public class DatasetReaderNew {
	private Casebase cb; // stores case objects
	private Map<Integer, Map<Integer, Double>> userProfiles; // stores training
																// user profiles
	private Map<Integer, Map<Integer, Double>> testProfiles; // stores test user
																// profiles
	Map<Integer, ArrayList<String>> reviewsMap;
	// private Stemmer st;

	private int i = 0;
	// stores term-document matrix
	MatrixTerm matrixTerm;
	MatrixTFIDF matrixTFIDF;

	/**
	 * constructor - creates a new DatasetReader object
	 * 
	 * @param trainFile
	 *            - the path and filename of the file containing the training
	 *            user profile data
	 * @param testFile
	 *            - the path and filename of the file containing the test user
	 *            profile data
	 * @param itemFile
	 *            - the path and filename of the file containing case metadata
	 */
	public DatasetReaderNew(final String trainFile, final String testFile,
			final String movieFile) {

		userProfiles = readUserProfiles(trainFile);
		// Set<Integer> users=getUserIds();

		i = 1;
		testProfiles = readUserProfiles(testFile);
		readCasebase(movieFile);

		buildTDMatrix();

	}

	/**
	 * @return the training user profile ids
	 */
	public Set<Integer> getUserIds() {
		return userProfiles.keySet();
	}

	/**
	 * @param id
	 *            - the id of the training user profile to return
	 * @return the training user profile
	 */
	public Map<Integer, Double> getUserProfile(final Integer id) {
		return userProfiles.get(id);
	}

	/**
	 * 
	 */
	public MatrixTFIDF getMatrixIFIDF() {
		return matrixTFIDF;
	}

	public MatrixTerm getMatrixTerm() {
		return matrixTerm;
	}

	/**
	 * @return the test user profile ids
	 */
	public Set<Integer> getTestIds() {
		return testProfiles.keySet();
	}

	/**
	 * @param id
	 *            - the id of the test user profile to return
	 * @return the test user profile
	 */
	public Map<Integer, Double> getTestProfile(final Integer id) {
		return testProfiles.get(id);
	}

	/**
	 * 
	 */
	public Map<Integer, ArrayList<String>> getReviewMap() {
		return reviewsMap;
	}

	/**
	 * @return the casebase
	 */
	public Casebase getCasebase() {
		return cb;
	}

	/**
	 * @param filename
	 *            - the path and filename of the file containing the user
	 *            profiles
	 * @return the user profiles
	 */
	private Map<Integer, Map<Integer, Double>> readUserProfiles(
			final String filename) {

		Map<Integer, Map<Integer, Double>> map = new HashMap<Integer, Map<Integer, Double>>();
		if (i == 0) {
			reviewsMap = new HashMap<Integer, ArrayList<String>>();
		}

		Set<String> stopWrds = new HashSet<String>(Arrays.asList("i", "a",
				"about", "an", "are", "as", "at", "be", "by", "com", "for",
				"from", "how", "in", "is", "it", "of", "on", "or", "that",
				"the", "this", "to", "movie", "film", "movies", "was", "what",
				"when", "where", "must", "who", "will", "with", "after",
				"again", "against", "all", "am", "and", "any", "as", "at",
				"be", "because", "been", "before", "being", "below", "between",
				"both", "but", "by", "cannot", "could", "did", "do", "does",
				"doing", "down", "during", "each", "few", "for", "from",
				"further", "had", "have", "haven", "having", "his", "her",
				"here", "hers", "herself", "him", "himself", "his", "if", "in",
				"into", "its", "itself", "let", "more", "most", "or", "other",
				"ought", "our", "ours", "same", "she", "should", "shouldn",
				"some", "such", "their", "hem", "themselves", "there", "these",
				"they", "those", "through", "to", "too", "under", "until",
				"up", "very", "was", "wasn", "we", "were", "weren", "what",
				"when", "where", "while", "who", "whom", "why", "with",
				"would", "your", "yours", "yourself", "yourselves"));

		// st=new Stemmer();

		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(
					filename)));
			String line;
			br.readLine(); // read in header line

			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, "\t");
				if (st.countTokens() != 4) {
					System.out.println("Error reading from file \"" + filename
							+ "\"");
					System.exit(1);
				}

				Integer userId = new Integer(st.nextToken());
				Integer movieId = new Integer(st.nextToken());
				Double rating = new Double(st.nextToken());
				String review = st.nextToken();
				//flag: only deal with the trainning set.
				if (i == 0) {
					//clean the review
					String[] test = review.replaceAll("[^a-zA-Z\\s]", "")
							.split(" ");

					// add the review words to the reviewsMap, while get rid of the stopwords
					ArrayList<String> reviews = null;
					if (reviewsMap.containsKey(movieId)) {
						reviews = reviewsMap.get(movieId);

					} else {
						reviews = new ArrayList<String>();
					}

					for (int i = 0; i < test.length; i++) {

						if ((test[i].trim().length() > 2)
								&& (!stopWrds.contains(test[i]))) {

							reviews.add(test[i]);

						}
					}

					
					reviewsMap.put(movieId, reviews);
				
				}

				Map<Integer, Double> profile = (map.containsKey(userId) ? map
						.get(userId) : new HashMap<Integer, Double>());
				profile.put(movieId, rating);
				map.put(userId, profile);

			}

			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}


		return map;
	}

	/**
	 * creates the casebase
	 * 
	 * @param filename
	 *            - the path and filename of the file containing the movie
	 *            metadata
	 */
	private void readCasebase(final String filename) {
		cb = new Casebase();

		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(
					filename)));
			String line;


			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, "\t");
				if (st.countTokens() != 5) {
					System.out.println("Error reading from file \"" + filename
							+ "\"");
					System.out.println(line);
					System.out.println(st.countTokens());
					System.exit(1);
				}

				Integer id = new Integer(st.nextToken());
				String title = st.nextToken();
				ArrayList<String> genres = tokenizeString(st.nextToken());
				ArrayList<String> directors = tokenizeString(st.nextToken());
				ArrayList<String> actors = tokenizeString(st.nextToken());

				MovieCase movie = new MovieCase(id, title, genres, directors,
						actors);

				cb.addCase(id, movie);

			}

			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		// System.out.println("cb has "+ cb.size());

	}

	/**
	 * Build the term-document matrix as matrixTerm 
	 * Build the TF-IDF matrix asmatrixTFIDF
	 */
	private void buildTDMatrix() {
		
		
		ArrayList<String> review = new ArrayList<String>();

		Set<Integer> movies = getCasebase().getIds();

		//generate term-doc matrix
		matrixTerm = new MatrixTerm();
		for (Integer movieId : movies) {
			//get the movie's review arraylist, then add elements
			review = this.getReviewMap().get(movieId);
			if (review != null) {
				for (int i = 0; i < review.size(); i++) {
					matrixTerm.addElement(movieId, review.get(i), 1);

				}
			}

		}

		System.out.println("Add matrix done!");

		// generate the TF-IDF matrix
		matrixTFIDF = new MatrixTFIDF();
		for (Integer movieId : matrixTerm.getMatrix().keySet()) {
			Map<String, Integer> row = matrixTerm.getMatrix().get(movieId);
			if (row != null) {
				for (String term : row.keySet()) {
					if (matrixTerm.getElement(movieId, term) != null) {
						matrixTFIDF.addElement(movieId, term,
								matrixTerm.getTFIDF(term, movieId));
					}
				}
			}
		}

		System.out.println("Calculate TF-IDF done!");

	}

	/**
	 * @param str
	 *            - the string to be tokenized; ',' is the delimiter character
	 * @return a list of string tokens
	 */
	private ArrayList<String> tokenizeString(final String str) {
		ArrayList<String> al = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(str, ",");
		while (st.hasMoreTokens())
			al.add(st.nextToken().trim());

		return al;
	}
}
