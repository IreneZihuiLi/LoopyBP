package util;

import java.util.ArrayList;
import java.util.Map;

import javax.tools.JavaCompiler;

public class CosineSimilarity{
	
	/**
	 * constructor
	 */
	public CosineSimilarity(){
		
	}
	
	
	/**
	 * calculate the cosine similarity given two maps
	 * @param map1
	 * @param map2
	 * @return
	 */
	public <T> double cosine_similarity(Map<String,T> map1,Map<String,T> map2) { 
        
		
		
		double [] vec1=new double[map1.size()];
		double [] vec2=new double[map2.size()];
		ArrayList<T> vList1=new ArrayList<T>();
		ArrayList<T> vList2=new ArrayList<T>();
		
		for(String term:map1.keySet()){
			vList1.add(map1.get(term));
		}
		
		for(int i=0;i<map1.size();i++){
			
			vec1[i]=Double.parseDouble(vList1.get(i).toString());
			
		}
		
		for(String term:map2.keySet()){
			vList2.add(map2.get(term));
		}
		
		for(int i=0;i<map2.size();i++){
			vec2[i]=Double.parseDouble(vList2.get(i).toString());
		}
			
		double dp = dot_product(map1,map2); 
        double magnitudeA = find_magnitude(vec1); 
        double magnitudeB = find_magnitude(vec2); 

        if(dp==0){
        	 	return 0;
        }else{
        		return (dp)/(magnitudeA*magnitudeB); 
        }
    } 

	/**
	 * calculate the magnitude of a given double array
	 * @param vect: the double array
	 * @return the magnitude
	 */
    private static double find_magnitude(double[] vec) { 
        double sum_mag=0; 
        int test=0;
        for(int i=0;i<vec.length;i++) 
        { 
        		if(test!=0)
        			test++;
        		
            sum_mag = sum_mag + vec[i]*vec[i]; 
        } 
        

        return Math.sqrt(sum_mag); 
    } 

    /**
     * calculate the dot product: only calculate the overlap term's values
     * @param map1
     * @param map2
     * @return dot product
     */
    private   <T> double dot_product(Map<String,T> map1,Map<String,T> map2) { 
        double sum=0; 
        for(String term:map1.keySet()){
        		if(map2.containsKey(term)){
        			sum=sum+Double.parseDouble(map1.get(term).toString())*Double.parseDouble(map2.get(term).toString());
        		}
        }
        
        return sum; 
    } 

    

}
