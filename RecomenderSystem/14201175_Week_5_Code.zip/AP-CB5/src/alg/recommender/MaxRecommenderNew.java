/**
 * A class to define a case-based recommender.
 * The scoring function used to rank recommendation candidates is the mean similarity to the target user's profile cases.
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.recommender;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import util.ScoredThingDsc;
import util.reader.DatasetReader;
import util.reader.DatasetReaderNew;
import alg.cases.similarity.CaseSimilarity;

public class MaxRecommenderNew extends RecommenderNew
{
	/**
	 * constructor - creates a new MeanRecommender object
	 * @param caseSimilarity - an object to compute case similarity
	 * @param reader - an object to store user profile data and movie metadata
	 */
	public MaxRecommenderNew(final CaseSimilarity caseSimilarity, final DatasetReaderNew reader)
	{
		super(caseSimilarity, reader);
	}
	
	/**
	 * returns a ranked list of recommended case ids
	 * @param userId - the id of the target user
	 * @param reader - an object to store user profile data and movie metadata
	 * @return the ranked list of recommended case ids
	 */
	public ArrayList<Integer> getRecommendations(final Integer userId, final DatasetReaderNew reader)
	{
		
		SortedSet<ScoredThingDsc> ss = new TreeSet<ScoredThingDsc>(); 
		
		// get the target user profile
		Map<Integer,Double> profile = reader.getUserProfile(userId);

		// get the ids of all recommendation candidate cases
		Set<Integer> candidateIds = reader.getCasebase().getIds();

		//Set an ArrayList to store all the scores get from the matrix
		ArrayList<Double> scores=null;
		

		// compute a score for all recommendation candidate cases
		for(Integer candidateId: candidateIds)
		{
			if(!profile.containsKey(candidateId)) // check that the candidate case is not already contained in the user profile
			{
				
				//initialize the ArrayList each time
				scores=new ArrayList<Double>();
				
				// iterate over all the target user profile cases and compute a score for the current recommendation candidate case
				for(Integer id: profile.keySet()) 
				{
					Double sim = super.getCaseSimilarity(candidateId, id);
					//put the similarity into the ArrayList scores.
					scores.add((sim != null) ? sim.doubleValue() : 0);
					
				}				

				if(Collections.max(scores) > 0){
					// we use the class Collections to find out the max value
					// add the max score for the current recommendation candidate case to the set
					ss.add(new ScoredThingDsc(Collections.max(scores), candidateId));
				}
				
			}
			
		}

		// sort the candidate recommendation cases by score (in descending order) and return as recommendations 
		ArrayList<Integer> recommendationIds = new ArrayList<Integer>();
		
		for(Iterator<ScoredThingDsc> it = ss.iterator(); it.hasNext(); )
		{
			ScoredThingDsc st = it.next();
			recommendationIds.add((Integer)st.thing);
		}
		
		return recommendationIds;
	}
}
