/**
FeatureSimilarity.java * A class to compute the case similarity between objects of type MovieCase
 * Uses the overlap feature similarity metric
 * 
 * Michael O'Mahony
 * 10/01/2013
 */

package alg.cases.similarity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import util.MatrixTFIDF;
import util.MatrixTerm;
import util.reader.DatasetReaderNew;
import alg.cases.Case;
import alg.cases.MovieCase;
import alg.feature.similarity.FeatureSimilarity;
import alg.feature.similarity.FeatureSimilarityNew;

public class CosineCaseSimilarity implements CaseSimilarity
{
	final static double GENRE_WEIGHT = 1; // the weight for feature genres
	final static double DIRECTOR_WEIGHT = 1; // the weight for feature directors
	final static double ACTOR_WEIGHT = 1; // the weight for feature actors
	final static double TERM_WEIGHT = 1; // the weight for the terms
	MatrixTFIDF matrixIFIDF;
	MatrixTerm matrixTerm;
	/**
	 * constructor - creates a new CosineCaseSimilarity object
	 */
	public CosineCaseSimilarity()
	{}
	
	/**
	 * new constructor - creates a new CosineCaseSimilarity object
	 */
	public CosineCaseSimilarity(DatasetReaderNew reader){
		this.matrixIFIDF=reader.getMatrixIFIDF();
		this.matrixTerm = reader.getMatrixTerm();
	
	}
	/**
	 * computes the similarity between two cases
	 * @param c1 - the first case
	 * @param c2 - the second case
	 * @return the similarity between case c1 and case c2
	 */
	public double getSimilarity(final Case c1, final Case c2) 
	{
		MovieCase m1 = (MovieCase)c1;
		MovieCase m2 = (MovieCase)c2;
		
		
		//Calculate TF-IDF case similarity.
//		double above = GENRE_WEIGHT * FeatureSimilarityNew.overlap(m1.getGenres(), m2.getGenres()) + 
//				DIRECTOR_WEIGHT * FeatureSimilarityNew.overlap(m1.getDirectors(), m2.getDirectors()) + 
//				ACTOR_WEIGHT * FeatureSimilarityNew.overlap(m1.getActors(), m2.getActors())+
//				TERM_WEIGHT * FeatureSimilarityNew.Cosine(matrixIFIDF.getMatrix().get(m1.getId()),matrixIFIDF.getMatrix().get(m2.getId()));
//		
		//Calculate before using TF-IDF case similarity.
		double above = GENRE_WEIGHT * FeatureSimilarityNew.overlap(m1.getGenres(), m2.getGenres()) + 
				DIRECTOR_WEIGHT * FeatureSimilarityNew.overlap(m1.getDirectors(), m2.getDirectors()) + 
				ACTOR_WEIGHT * FeatureSimilarityNew.overlap(m1.getActors(), m2.getActors())+
				TERM_WEIGHT * FeatureSimilarityNew.Cosine(matrixTerm.getMatrix().get(m1.getId()),matrixTerm.getMatrix().get(m2.getId()));
		
		double below = GENRE_WEIGHT + DIRECTOR_WEIGHT + ACTOR_WEIGHT + TERM_WEIGHT;
		return (below > 0) ? above / below : 0;
	}
}
